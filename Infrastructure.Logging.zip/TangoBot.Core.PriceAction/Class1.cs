﻿namespace TangoBot.Core.PriceAction
{
    public class Class1
    {

    }
}
