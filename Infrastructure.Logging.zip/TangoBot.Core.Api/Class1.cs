﻿namespace TangoBot.Core.Api
{
    public class Class1
    {

    }
}
